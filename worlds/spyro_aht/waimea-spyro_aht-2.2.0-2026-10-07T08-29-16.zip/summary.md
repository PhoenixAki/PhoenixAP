# Waimea report: Spyro: A Hero's Tail (spyro_aht v2.2.0)

Run in a browser on 2026-10-07T08:29:16.325Z, against Archipelago 0.6.8. The index CI remains the authoritative check.

# Unit tests

**Archipelago 0.6.8** — _ionium-ap/Archipelago@2ae0d22 (0.6.8-ionium.1), fuzzer 53686ba_

## ✅ spyro_aht v2.2.0

_All unit tests passed._

# Fuzzing

_Timeouts were scaled by this browser's speed, measured on Archipelago 0.6.7's TUNIC._

**Archipelago 0.6.8** — _ionium-ap/Archipelago@2ae0d22 (0.6.8-ionium.1), fuzzer 53686ba_

## Fuzz results for spyro_aht v2.2.0

### default

```
Success: 4998
Failure: 2
Timeout: 0
Ignored: 0
Total: 5000
```
**Failure rate**: 0.0%

**Errors:**
- `FillError` (×2)

_Timeout 37 s (CI's 30 s, scaled by calibration)._


### no-restrictive-starts

```
Success: 5000
Failure: 0
Timeout: 0
Ignored: 0
Total: 5000
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration)._


### ✅ check-collect-accessibility

<details>
<summary>Details</summary>

Fuzz to check that collecting items into a state doesn't reduce accessibility

```
Success: 500
Failure: 0
Timeout: 0
Ignored: 0
Total: 500
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration)._

</details>

### ✅ check-determinism

<details>
<summary>Details</summary>

Fuzz to check for determinism

```
Success: 500
Failure: 0
Timeout: 0
Ignored: 0
Total: 500
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration); 4 worker pairs, each regenerating its seeds in a second interpreter._

</details>

### ✅ check-gerpocalypse

<details>
<summary>Details</summary>

Fuzz to check for issues with GER

```
Success: 500
Failure: 0
Timeout: 0
Ignored: 0
Total: 500
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration)._

</details>

### ✅ check-indirect-conditions

<details>
<summary>Details</summary>

Fuzz to check for missing indirect conditions

```
Success: 499
Failure: 0
Timeout: 0
Ignored: 1
Total: 500
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration)._

</details>

### ✅ check-item-location-count

<details>
<summary>Details</summary>

Fuzz to check that the item count matches the location count

```
Success: 500
Failure: 0
Timeout: 0
Ignored: 0
Total: 500
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration)._

</details>

### ✅ check-lambda-capture

<details>
<summary>Details</summary>

Fuzz to find out if there's some lambda variable capture issues

```
Success: 500
Failure: 0
Timeout: 0
Ignored: 0
Total: 500
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration)._

</details>

### ✅ check-placement-item-location-refs

<details>
<summary>Details</summary>

Fuzz to check if items/locations agree on their placements

```
Success: 498
Failure: 0
Timeout: 0
Ignored: 2
Total: 500
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration)._

</details>

### ✅ check-static-output-placement

<details>
<summary>Details</summary>

Fuzz to check that the world doesn't modify placements in output

```
Success: 499
Failure: 0
Timeout: 0
Ignored: 1
Total: 500
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration)._

</details>

### ✅ check-ut

<details>
<summary>Details</summary>

Fuzz to check for universal tracker support

```
Success: 499
Failure: 0
Timeout: 0
Ignored: 1
Total: 500
```
**Failure rate**: 0.0%

_Timeout 37 s (CI's 30 s, scaled by calibration)._

</details>
